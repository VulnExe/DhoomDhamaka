import React from "react";
// import "./corpeve.css";
import CorporateForm from "./formcomponents/corporate event/corporateform";

export default function corporateevent() {
  return (
    <div>
    
     <CorporateForm/>
    </div>
  );
}