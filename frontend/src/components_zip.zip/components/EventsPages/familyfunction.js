import React from "react";
// import "./familfunc.css";
import FamilyfunctionForm from "./formcomponents/FamilyFunctionevent/familyfunctionform";

export default function Familyfunction() {
  return (
    <div>
      <FamilyfunctionForm/>
    </div>
  );
}


