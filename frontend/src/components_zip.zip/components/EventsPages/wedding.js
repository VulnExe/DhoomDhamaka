import React from 'react'
import Weddingform from './formcomponents/weddingform/weddingform'

export default function Wedding() {
  return (
    <div>
      <Weddingform/>
    </div>

  )
}