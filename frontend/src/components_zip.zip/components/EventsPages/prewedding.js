import React from 'react'
import PreweddingForm from './formcomponents/PreWeddingform/preweddingform'

export default function Prewedding() {
  return (
    <div>
      <PreweddingForm/>
    </div>
  )
}