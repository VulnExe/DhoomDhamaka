import React from 'react'
// import "./babyshower.css"
import BabyShowerForm from './formcomponents/babyshowerevent/babyshowerevent'
export default function Babyshower() {
  return (
   <div>
     <BabyShowerForm/>
   </div>
  )
}