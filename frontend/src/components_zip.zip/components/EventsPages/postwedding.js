import React from "react";
// import "./postwed.css";
import PostweddingForm from "./formcomponents/postweddingform/postweddingform";

function Postwedding() {
  return (
    <div>
     <PostweddingForm/>
    </div>
  );
}

export default Postwedding;